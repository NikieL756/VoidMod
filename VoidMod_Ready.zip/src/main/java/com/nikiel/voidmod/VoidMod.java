
package com.nikiel.voidmod;

import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.event.FMLInitializationEvent;

@Mod(modid = "voidmod", name = "Void Mod", version = "1.0")
public class VoidMod {
    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        System.out.println("VoidMod loaded!");
    }
}
